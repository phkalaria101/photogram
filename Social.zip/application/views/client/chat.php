<div id="chat_bar">


<div id="active_chats">

</div>

<audio id="bleep" controls>
    <source src="<?php echo base_url() ?>images/audio/beep.mp3" type="audio/mpeg">
</audio>

</div>